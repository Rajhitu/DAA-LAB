
// #include<stdio.h>
// #include<stdlib.h>

// int prod(int n, int arr[n]){
//    int result = 1;
//    int i;
//    for (i=0;i<n;i++){
//    result = result * arr[i];
//    }
//    return result;
// }
// int main(){
//     int n,i;
    
//     printf("Enter the size of array\n");
//     scanf("%d",&n);
//     int arr[n];
//     printf("Enter the contents of array\n");
//     for(i=0;i<n;i++){
//     scanf("%d",&arr[i]);
//     }
//     int pro;
//     pro=prod(n,arr);
//     printf("The output array is\n");
//     for(i=0;i<n;i++){
//        arr[i]=pro/arr[i]; 
//        printf("%d ",arr[i]);
//     }
   
    
// }