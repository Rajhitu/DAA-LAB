 while (countinue==1)
   
//    {
// printf("enter in ascending order\n")


//    }