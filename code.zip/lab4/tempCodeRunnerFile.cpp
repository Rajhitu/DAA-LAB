cout<<str<<" \n";
cout<<res;