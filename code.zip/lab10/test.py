arr = [21, 23, 4, 2, 12]

rearr = arr
# sort(rearr)

print(rearr[0])


