#include<bits/stdc++.h>
#include<vector>
using namespace std;
int main()
{
   vector <int> a={1,12,4,10,2,6};

sort(a.begin(),a.end());

for (int i = 0; i < a.size(); i++)
{
    cout<<a[i]<<" ";
}



    return 0;
}